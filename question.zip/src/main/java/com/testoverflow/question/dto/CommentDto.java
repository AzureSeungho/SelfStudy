package com.testoverflow.question.dto;

public class CommentDto {
    // 작성자 등록일자 사용여부 useYN
   // (PK)
    private int commentNum; // 댓글번호

    // 글번호 (부모의 글번호 (FK))
    private int questionNo; // 글번호
    private String comment; // 댓글

    private String user; // 작성자

    private int monthValue;
    private int day;
    private int year;
    private String formatedTime;

    public int getCommentNum() {
        return commentNum;
    }

    public void setCommentNum(int commentNum) {
        this.commentNum = commentNum;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public int getQuestionNo() {
        return questionNo;
    }

    public void setQuestionNo(int questionNo) {
        this.questionNo = questionNo;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public int getMonthValue() {
        return monthValue;
    }

    public void setMonthValue(int monthValue) {
        this.monthValue = monthValue;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getFormatedTime() {
        return formatedTime;
    }

    public void setFormatedTime(String formatedTime) {
        this.formatedTime = formatedTime;
    }

    @Override
    public String toString() {
        return "CommentDto{" +
                "commentNum=" + commentNum +
                ", questionNo=" + questionNo +
                ", comment='" + comment + '\'' +
                '}';
    }
}
