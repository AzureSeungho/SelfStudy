package com.testoverflow.question.dto;

public class CommentDto {
    // 작성자 등록일자 사용여부 useYN
   // (PK)
    private int commentNum; // 댓글번호

    // 글번호 (부모의 글번호 (FK))
    private int questionNo; // 글번호
    private String comment; // 댓글

    private String user; // 작성자

    private String createDate;

    public int getCommentNum() {
        return commentNum;
    }

    public void setCommentNum(int commentNum) {
        this.commentNum = commentNum;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public int getQuestionNo() {
        return questionNo;
    }

    public void setQuestionNo(int questionNo) {
        this.questionNo = questionNo;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    @Override
    public String toString() {
        return "CommentDto{" +
                "commentNum=" + commentNum +
                ", questionNo=" + questionNo +
                ", comment='" + comment + '\'' +
                '}';
    }
}
