package com.testoverflow.question.dto;

import java.util.ArrayList;
import java.util.List;

public class QuestionDto {
    private String title;
    private String content;

    private String name; // first last 합칠꺼임 ㅇㅇ

    private String createDate;

    private List<CommentDto> commentDtoList = new ArrayList<>();
    // 글번호
    private int questionNO = 0; // listNo or questionNo

    private String useYN;

    public String getUseYN() {
        return useYN;
    }

    public void setUseYN(String useYN) {
        this.useYN = useYN;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getQuestionNO() {
        return questionNO;
    }

    public void setQuestionNO(int questionNO) {
        this.questionNO = questionNO;
    }

    public List<CommentDto> getCommentDtoList() {
        return commentDtoList;
    }

    public void setCommentDtoList(List<CommentDto> commentDtoList) {
        this.commentDtoList = commentDtoList;
    }

    public String getCreateDate() {
        return createDate;
    }
    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }
}
