package com.testoverflow.question.dto;

import java.util.ArrayList;
import java.util.List;

public class QuestionDto {
    private String firstname;
    private String lastname;
    private String title;
    private String content;

    private int monthValue;
    private int day;
    private int year;
    private String formatedTime;

    private List<CommentDto> commentDtoList = new ArrayList<>();
    // 글번호
    private int questionNO = 0; // listNo or questionNo

    private String useYN;

    public String getUseYN() {
        return useYN;
    }

    public void setUseYN(String useYN) {
        this.useYN = useYN;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getQuestionNO() {
        return questionNO;
    }

    public void setQuestionNO(int questionNO) {
        this.questionNO = questionNO;
    }

    public List<CommentDto> getCommentDtoList() {
        return commentDtoList;
    }

    public void setCommentDtoList(List<CommentDto> commentDtoList) {
        this.commentDtoList = commentDtoList;
    }

    public int getMonthValue() {
        return monthValue;
    }

    public void setMonthValue(int monthValue) {
        this.monthValue = monthValue;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getFormatedTime() {
        return formatedTime;
    }

    public void setFormatedTime(String formatedTime) {
        this.formatedTime = formatedTime;
    }

    @Override
    public String toString() {
        return "QuestionDto{" +
                "firstname='" + firstname + '\'' +
                ", lastname='" + lastname + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", monthValue=" + monthValue +
                ", day=" + day +
                ", year=" + year +
                ", formatedTime='" + formatedTime + '\'' +
                ", commentDtoList=" + commentDtoList +
                ", questionNO=" + questionNO +
                ", useYN='" + useYN + '\'' +
                '}';
    }
}
