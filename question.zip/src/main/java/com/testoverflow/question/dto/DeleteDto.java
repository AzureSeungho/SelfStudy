package com.testoverflow.question.dto;

public class DeleteDto {
    private int questionNo;

    public int getQuestionNo() {
        return questionNo;
    }

    public void setQuestionNo(int questionNo) {
        this.questionNo = questionNo;
    }
}
