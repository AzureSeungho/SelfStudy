package com.testoverflow.question.controller;

import com.testoverflow.question.dto.CommentDto;
import com.testoverflow.question.dto.QuestionDto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/")
public class QuestionController {
    private final List<QuestionDto> questionList;
    // questionList 이름 바꾸기

//    private final List<CommentDto> Clist;

    public QuestionController(){
        questionList = new ArrayList<>();
//        Clist = new ArrayList<>();
    }

    private int count = 0;
    private int commentNum = 0;

    @GetMapping("/Main")
    public String goMain(Model model){
        // questionList 에서 useYN = "Y" 인것만 뿌려주기
        // 수정하기 추가하지말고 (일단) 삭제하면 delete(DB) 했는데
        // update 로 바꿔서 flag로 관리 해야한다.
        // for문 사용
        List<QuestionDto> useYList = new ArrayList<>();

        for(int i =0;i<questionList.size();i++){
            if(questionList.get(i).getUseYN().equals("Y")){
                useYList.add(questionList.get(i));//questionList.get(i) =i 번째 인덱스를 가져옴(가져온 값은 questionDto임)
                //왜? -> 위에서 List<QuestionDto> questionList로 선언해줘서 questionList는 QuestionDto를 받는 리스트임
            }
        }
        if(useYList.isEmpty()){
            model.addAttribute("isEmpty","등록된 글이 없습니다.");
        }
        model.addAttribute("QuestionList",useYList);
        return "main.html";
    }
    @GetMapping("/deletedList")
    public String seeNList(Model model){
        List<QuestionDto> useNList = new ArrayList<>();

        for(int i=0;i<questionList.size();i++){
            if (questionList.get(i).getUseYN().equals("N")) {
                useNList.add(questionList.get(i));
                model.addAttribute("useNlist", useNList);
            }
        }
        if(useNList.isEmpty()){
            model.addAttribute("isEmpty","삭제된 글이 없습니다.");
        }
        return "deletedList.html";
    }

    @GetMapping("/Question")
    public String goQuestion(){
      return "question.html";
    }


    @PostMapping("/Upload")//글 작성
    public String upLoad(@RequestParam("firstName") String firstname, @RequestParam("lastName") String lastname, @RequestParam("title") String title,
    @RequestParam("content") String content, Model model){
      count++;

        QuestionDto questionDto = new QuestionDto();

        questionDto.setFirstname(firstname);
        questionDto.setLastname(lastname);
        questionDto.setTitle(title);
        questionDto.setContent(content);
        questionDto.setQuestionNO(count);

        LocalDate YearNow = LocalDate.now();
        int monthValue = YearNow.getMonthValue();
        int day = YearNow.getDayOfMonth();
        int year = YearNow.getYear();

        LocalDateTime TimeNow = LocalDateTime.now();
        String formatedTime = TimeNow.format(DateTimeFormatter.ofPattern("HH:mm:ss"));

        questionDto.setMonthValue(monthValue);
        questionDto.setDay(day);
        questionDto.setYear(year);
        questionDto.setFormatedTime(formatedTime);
        questionDto.setUseYN("Y");

        questionList.add(questionDto);
//        System.out.println(questionList.toString());

        return "redirect:/Main";
    }

    @GetMapping("/detail/{questionNo}")//글 상세 보기
    public String detail(@PathVariable int questionNo, Model model){
        String title = "";
        String content="";
        QuestionDto questionDto = null;
        for(int i = 0;i<questionList.size(); i++){
            int a = questionList.get(i).getQuestionNO();
            if(a == questionNo){
                title = questionList.get(i).getTitle();
                content = questionList.get(i).getContent();
                //comment = questionList.get(i).getComment();

                questionDto = questionList.get(i);

            }
        }

        model.addAttribute("question",questionDto);
        model.addAttribute("Comment",questionDto.getCommentDtoList());

        return "seeDetail.html";

    }

    @PostMapping("/Comment")//댓글
    public String comment(@ModelAttribute CommentDto commentDto){

        LocalDate YearNow = LocalDate.now();
        int monthValue = YearNow.getMonthValue();
        int day = YearNow.getDayOfMonth();
        int year = YearNow.getYear();

        LocalDateTime TimeNow = LocalDateTime.now();
        String formatedTime = TimeNow.format(DateTimeFormatter.ofPattern("HH:mm:ss"));


        // 1. 받은 글번호로 questionList에서 해당 글 찾기
        for(int i=0;i<questionList.size();i++){
            if(questionList.get(i).getQuestionNO() == commentDto.getQuestionNo()){

//              for -> 해당 질문의 마지막 코멘트NO 찾기 -> 마지막 값이 최대값인지 체크
                int commentNo = 0;
                for(int x =0;x<questionList.get(i).getCommentDtoList().size();x++){
                    commentNo = questionList.get(i).getCommentDtoList().get(x).getCommentNum();
                }
                commentDto.setCommentNum(++commentNo);
//                commentDto.setUser(commentDto.getUser());
                commentDto.setMonthValue(monthValue);
                commentDto.setDay(day);
                commentDto.setYear(year);
                commentDto.setFormatedTime(formatedTime);
                questionList.get(i).getCommentDtoList().add(commentDto);

            }
        }
//       System.out.println(questionList.toString());

        return "redirect:/detail/"+commentDto.getQuestionNo();
    }

    // 삭제하기 버튼 만들어서 삭제하기 누르면 삭제되도록 컨트롤러 만들기(useYN)
    @GetMapping("/delete/{questionNO}")
    public String deleteList(@PathVariable int questionNO){
        for(int i=0;i<questionList.size();i++){
            if(questionList.get(i).getQuestionNO() == questionNO){
//                System.out.println("same");
                questionList.get(i).setUseYN("N");
            }
        }
//        System.out.println(questionList.toString());

        return "redirect:/Main";
    }

}


