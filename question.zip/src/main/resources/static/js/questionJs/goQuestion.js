$(".goQuestion").on("click",function(){
    location.href= "/Question";
})