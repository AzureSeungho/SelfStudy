$('.contentDetail').on('click',function(){
    console.log($(this).val())
    const questionNo = $(this).val();
    location.href = '/detail/'+questionNo
})