$('.noUse').on('click',function(){
    console.log($('#questionNO').val())
    // 1. 다른 인풋태그의 value 값 가져오는방법 찾아보기
    const questionNO = $('#questionNO').val();
    location.href='/delete/'+questionNO
});