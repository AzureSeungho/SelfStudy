$('.noUse').on('click',function(){
    if(confirm("삭제하시겠습니까? 이 행동은 되돌릴 수 없습니다.")){
            console.log($('#questionNO').val())
            // 1. 다른 인풋태그의 value 값 가져오는방법 찾아보기
            const questionNO = $('#questionNO').val();
            location.href='/delete/'+questionNO
    }
    else{
        return false;
    }
});