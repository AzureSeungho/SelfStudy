$(document).ready(function(){
//change 클래스 클릭 이벤트(a태그임)
    $('.change').click(function(event){
        $('.change').addClass("active");
        $('.change').removeClass("active");
    });
});