package com.testoverflow.newest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewestApplicationTests {

	@Test
	void contextLoads() {
	}

}
