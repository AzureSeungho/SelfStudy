$('.contentDetail').on('click',function(){
    console.log($(this).val())
    const listTitle = $(this).val();
    location.href = '/detail/'+listTitle
})