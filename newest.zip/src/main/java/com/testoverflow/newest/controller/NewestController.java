package com.testoverflow.newest.controller;

import com.testoverflow.newest.dto.QuestionDto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/")
public class NewestController {
    private final List<QuestionDto> Qlist;

    public NewestController(){
        Qlist = new ArrayList<>();
    }

    private int count = 0;

    @GetMapping("/Main")
    public String goMain(Model model){
        model.addAttribute("QuestionList",Qlist);
        return "Main.html";
    }

    @GetMapping("/Question")
    public String goQuestion(){
      return "Question.html";
    }


    @PostMapping("/Upload")
    public String upLoad(@RequestParam("firstName") String firstname, @RequestParam("lastName") String lastname, @RequestParam("title") String title,
    @RequestParam("content") String content, Model model){
        count++;

        QuestionDto questionDto = new QuestionDto();

        questionDto.setFirstname(firstname);
        questionDto.setLastname(lastname);
        questionDto.setTitle(title);
        questionDto.setContent(content);
        questionDto.setCount(count);

        Qlist.add(questionDto);

        return "redirect:/Main";
    }
    @GetMapping("/detail/{listTitle}")
    public String detail(@PathVariable String listTitle,Model model){
        int i;
        String title = "";
        String content="";

        for(i = 0;i<Qlist.size(); i++){
            String a = Qlist.get(i).getTitle();
            if(a.equals(listTitle)){
                title = Qlist.get(i).getTitle();
                content = Qlist.get(i).getContent();
            }
        }
        model.addAttribute("title",title);
        model.addAttribute("content",content);
        return "seeTitle.html";
    }
}
