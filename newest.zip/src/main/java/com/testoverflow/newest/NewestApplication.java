package com.testoverflow.newest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewestApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewestApplication.class, args);
	}

}
