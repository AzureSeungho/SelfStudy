
$('.enquireDetail').on('click',function(){
//    $(this).val()
    console.log($(this).val())
    const listNo = $(this).val();
    location.href = '/findContent/' + listNo
})