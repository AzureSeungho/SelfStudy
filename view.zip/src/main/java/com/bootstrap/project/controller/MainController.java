package com.bootstrap.project.controller;

import com.bootstrap.project.dto.EnquireDto;
import com.bootstrap.project.dto.UserDto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Controller
@RequestMapping("/")
public class MainController {
    private final List<EnquireDto> enList;

    private int listNo = 0;

    public MainController(){
        enList = new ArrayList<>();
    }

    @GetMapping("/enquire")
    public String enquire(){
        return "enquire.html";
    }

    @GetMapping("/back")
    public String back(){
        return "redirect:/List";
    }

    @GetMapping("/List")
    public String goMain(Model model){
        model.addAttribute("EnquireList",enList);
        return "ListPage.html";
    }
    @GetMapping("cover")
    public String cover(){
        return "Cover.html";
    }
    @PostMapping("/DoEnquire")//모델 클래스 main 에 불러오고 model attribute를 /main 에 복사한 후 여기서는 redirect로 /main으로 보내기
    public String DoEnquire(@RequestParam("classfication")String classf,@RequestParam("title")String title,@RequestParam("content")String content,@RequestParam("id")String id,Model model){
        listNo++;
        EnquireDto enquireDto = new EnquireDto();
        enquireDto.setClassf(classf);
        enquireDto.setId(id);
        enquireDto.setTitle(title);
        enquireDto.setContent(content);
        enquireDto.setListNo(listNo);

        enList.add(enquireDto);


        return "redirect:/List";
    }

    @GetMapping("/findContent/{listNo}")
    public String findContent(@PathVariable Integer listNo, Model model){
        int i;
        String content = "";

        // 1. 해당 리스트넘버를 이용해서 리스트에 들어있는 문의글 찾기 (리스트넘버에 맞는)
        for(i = 0; i < enList.size(); i++){
            int a = enList.get(i).getListNo();
            if(a == listNo){
                content = enList.get(i).getContent();
            }
        }

        model.addAttribute("content",content);
        //System.out.println(content);
        return "seeContent.html";
    }
}
