package com.bootstrap.project.dto;

public class EnquireDto {
    private String classf;
    private String title;
    private String content;
    //public String date; 글 번호 ,날짜 , 상제 정보 번호로 구분하기
    private String id;

    private Integer ListNo;

    public String getClassf() {
        return classf;
    }

    public void setClassf(String classf) {
        this.classf = classf;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getListNo() {
        return ListNo;
    }

    public void setListNo(Integer listNo) {
        ListNo = listNo;
    }

    @Override
    public String toString() {
        return "EnquireDto{" +
                "classf='" + classf + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", id='" + id + '\'' +
                ", ListNo=" + ListNo +
                '}';
    }
}
