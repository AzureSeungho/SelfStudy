package com.bootstrap.project.view;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViewApplicationTests {

	@Test
	void contextLoads() {
	}

}
