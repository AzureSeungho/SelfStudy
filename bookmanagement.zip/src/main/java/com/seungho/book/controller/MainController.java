package com.seungho.book.controller;

import com.seungho.book.dto.BookDbDto;
import com.seungho.book.dto.BookDto;
import com.seungho.book.dto.SearchDto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.swing.plaf.nimbus.State;
import java.awt.print.Book;
import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/")
public class MainController {


    @GetMapping("/select")
    public String select(){
        return "select_function.html";
    }

    //책 관리 프로그램 시작점
    @GetMapping("/register")
    public String register(){
        return "registerbook.html";
    }

    @GetMapping("/searchbook")
    public String searchbook(){
        return "search.html";
    }

    @GetMapping("/showLists")
    public String showList(Model model) throws IOException, SQLException {

        String server = "localhost";
        String username = "root";
        String password = "0000";
        String db = "book";
        String port = "3306";

        String sql = "select * from bookinfo";

        Connection conn = DriverManager.getConnection("jdbc:mysql://"+server+":"+port+"/"+db,username,password);
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(sql);

        List<BookDbDto> bookList = new ArrayList<>();

        while(rs.next()) {
            BookDbDto bookdb = new BookDbDto();
            String bookname = rs.getString("name");
            String bookauthor = rs.getString("author");
            String bookpublisher = rs.getString("publisher");
            String bookdate = rs.getString("date");

            bookdb.setBookname(bookname);
            bookdb.setBookauthor(bookauthor);
            bookdb.setBookpublisher(bookpublisher);
            bookdb.setBookdate(bookdate);

            bookList.add(bookdb);
        }
        model.addAttribute("bookinfos",bookList);
        return "BookLists.html";
    }

    @GetMapping("/back")
    public String back(){
        return "redirect:/select";
    }

    @GetMapping("/update")//업데이트 관련
    public String update(){
        return "update.html";
    }

    @PostMapping("/re")//registerbook.html에서 받아온 값들을 db 접속후 테이블에 넣기
    public String  re(@RequestParam("name") String name, @RequestParam("author") String author, @RequestParam("publisher") String publisher, @RequestParam("date") String date) throws IOException, SQLException {
        String server = "localhost";
        String username = "root";
        String password = "0000";
        String db = "book";
        String port = "3306";

        String sql = "insert into bookinfo values(?,?,?,?)";


        Connection conn = DriverManager.getConnection("jdbc:mysql://"+server+":"+port+"/"+db,username,password);

        PreparedStatement ps = conn.prepareStatement(sql);

        ps.setString(1,name);
        ps.setString(2,author);
        ps.setString(3,publisher);
        ps.setString(4,date);

        ps.executeUpdate();
        return "redirect:/select";
    }

    @PostMapping("/searchpro")
    public String searchpro(@RequestParam("searchname") String SearchedName, Model model) throws SQLException {
        String server = "localhost";
        String username = "root";
        String password = "0000";
        String db = "book";
        String port = "3306";

        String sql = "select * from bookinfo where name = '"+SearchedName+"'";

        Connection conn = DriverManager.getConnection("jdbc:mysql://"+server+":"+port+"/"+db,username,password);
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(sql);
        rs.next();

        SearchDto searchDto = new SearchDto();

        List<SearchDto> searchList = new ArrayList<>();

        String a = rs.getString("name");
        String b = rs.getString("author");
        String c = rs.getString("publisher");
        String d = rs.getString("date");

        searchDto.setName(a);
        searchDto.setAuthor(b);
        searchDto.setPublisher(c);
        searchDto.setDate(d);

        searchList.add(searchDto);

        model.addAttribute("searchedbook",searchList);

        return "searched.html";
    }

    @PostMapping("/del")
    public String delbook(@RequestParam("delname") String delname) throws SQLException {
        String server = "localhost";
        String username = "root";
        String password = "0000";
        String db = "book";
        String port = "3306";

        String sql = "delete from bookinfo where name = ? ";

        Connection conn = DriverManager.getConnection("jdbc:mysql://"+server+":"+port+"/"+db,username,password);
        PreparedStatement ps = conn.prepareStatement(sql);

        ps.setString(1,delname);
        ps.executeUpdate();

        return "redirect:/select";
    }

    @PostMapping("/GoUpdate")
    public String GoUpdate(@RequestParam("updatename") String name,@RequestParam("updateauthor")String author,@RequestParam("updatepublisher")String publisher,@RequestParam("updatedate")String date) throws SQLException {
        String server = "localhost";
        String username = "root";
        String password = "0000";
        String db = "book";
        String port = "3306";

        String sql = "update bookinfo set author = ? , publisher = ? , date = ? where name = ?";

        Connection conn = DriverManager.getConnection("jdbc:mysql://"+server+":"+port+"/"+db,username,password);
        PreparedStatement ps = conn.prepareStatement(sql);

        ps.setString(1,author);
        ps.setString(2,publisher);
        ps.setString(3,date);
        ps.setString(4,name);
        ps.executeUpdate();

        return "redirect:/select";
    }
    //책 관리 프로그램 끝
}